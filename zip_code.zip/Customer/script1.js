<script>
function register() {
    document.location.href="register.html";
    
}
</script>